<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DW_COMPANY</title>
    <?php wp_head();?>
</head>
<body>
<div class="container">
<nav class="nav">
<ul>
        <li><a href="#">Главная</a></li>
    <li><a href="#">Примеры работ</a></li>
    <li><a href="#">Наши услуги</a></li>
    <li><a href="">Связаться с нами</a></li>
    <li><a href="">Блог</a></li>
        </ul>
    </nav>

    <div class="text_position_img">



        <ul class="DW_01_company">
<li class="top_DW">DW</li>
           <li class="top_01">01</li>
        <li class="top_company">COMPANY</li>

    </ul>
        <h2 class="top_p2">Автоматизируйте свой бизнес с помощью наших умных ботов и сайтов</h2>

    </div>


</div>
<footer>
    <div class="footer">


        <ul>
            <li><a href="https://vk.com/dw_company1990"><img src="./img/icons8-vk-circled-48.png" alt="vk"></a></li>
            <li><a href="https://t.me/dw_company_bot"><img src="./img/icons8-telegram-app-48.png" alt="telegram"></a></li>
            <li><a href="https://chat.whatsapp.com/KOscwSuOiW46WR4tSvHp9s"><img src="./img/icons8-whatsapp-48.png" alt="WhatsApp"></a></li>
            <li><a href="https://www.youtube.com/@darkwolf19906"><img src="./img/icons8-youtube-48.png" alt="youtube"></a></li>
        </ul>
    </div>

</footer>
<?php wp_footer();?>
</body>
</html>